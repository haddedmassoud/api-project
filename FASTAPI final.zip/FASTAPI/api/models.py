# api/models.py
from pydantic import BaseModel
from typing import List

class RecipeIn(BaseModel):
    title: str
    ingredients: str
    servings: str
    instructions: str

class RecipeOut(BaseModel):
    id: int
    recipe: RecipeIn
