from fastapi import APIRouter, HTTPException, Request, Depends,Query
from fastapi.responses import JSONResponse
from api.models import RecipeIn, RecipeOut
import requests
from typing import List

from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
ouath_scheme = OAuth2PasswordBearer(tokenUrl="token")
router = APIRouter()

@router.post("/token", description="Generate an access token")
async def token_generate(
    form_data: OAuth2PasswordRequestForm = Depends()
):
    """
    Endpoint to generate an access token using OAuth2 password flow.

    - **form_data**: OAuth2PasswordRequestForm object containing the username and password.

    Returns:
    - **access_token**: The generated access token.
    - **token_type**: The type of token (e.g., "bearer").
    """
    return {"access_token": form_data.username, "token_type": "bearer"}

recipes = []

async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail},
    )
@router.get("/get_recipe")
async def get_recipe(
    request: Request,
    token: str = Depends(ouath_scheme),
    query: str = Query("", description="Query string for recipe search in the external API")
):
    """
    Get recipes from an external API.

    Parameters:
    - token (str): The OAuth2 token for authentication.
    - query (str): The query string for recipe search in the external API.

    Returns:
    - dict: External recipe data.
    """
    global recipes
    url = 'https://recipe-by-api-ninjas.p.rapidapi.com/v1/recipe'
    headers = {
        'X-RapidAPI-Key': '0597d15aebmsh830e40a2a6e4346p191508jsn0bcf1770c3c2',
        'X-RapidAPI-Host': 'recipe-by-api-ninjas.p.rapidapi.com'
    }

    try:
        params = {'query': query}

        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        print(response)
        external_recipe = response.json()

        # Append the external recipe data to the local recipes array
        new_recipes = [{"id": len(recipes) + i + 1, "recipe": recipe} for i, recipe in enumerate(external_recipe)]

        # Append the new recipes to the global recipes array
        recipes.extend(new_recipes)
        print(recipes)
        return external_recipe
    except requests.exceptions.RequestException as error:
        raise HTTPException(status_code=500, detail=f"Recipe API request failed: {error}")


@router.get("/recipes")
def read_recipes(token: str = Depends(ouath_scheme)):
    """
    Retrieve a list of recipes.

    This endpoint requires authentication using an OAuth2 token.

    Parameters:
    - token (str): The OAuth2 token for authentication.

    Returns:
    - List[dict]: A list of recipes. Each recipe is represented as a dictionary.

    Raises:
    - HTTPException(500): If there is an internal server error during the retrieval process.
    """
    try:
        global recipes
        # Validate the data against the Recipe model before returning
        return recipes
    except Exception as error:
        print(f"Error in /recipes endpoint: {error}")
        raise HTTPException(status_code=500, detail="Internal Server Error")


# Route to create a new recipe
@router.post("/recipes", response_model=list[RecipeOut], summary="Create a new recipe")
async def create_recipe(
    request: Request,
    recipe_in: RecipeIn,
    token: str = Depends(ouath_scheme)
):
    """
    Create a new recipe.

    :param request: The FastAPI request object.
    :param recipe_in: The recipe details to be created.
    :param token: The OAuth token for authentication.

    :return: List of all recipes including the new one.
    """
    new_recipe = {"id": len(recipes) + 1, "recipe": recipe_in}
    recipes.append(new_recipe)
    return recipes

# Route to update a recipe
@router.put("/recipes", response_model=RecipeOut, description="Update a recipe")
async def update_recipe(
    request: Request,
    recipe_update: RecipeIn,
    request_body: dict,  # Added request body parameter
    token: str = Depends(ouath_scheme)
):
    """
    Update a recipe.

    :param request: The FastAPI request object.
    :param recipe_update: The updated recipe details.
    :param request_body: The additional request body parameter for JSON input.
    :param token: The OAuth token for authentication.

    :return: The updated recipe.
    """
    # Update the recipe details with the additional information from the request body
    request_body_dict = request_body.get("recipe", {})
    recipe_update.title = request_body_dict.get("title", recipe_update.title)
    recipe_update.ingredients = request_body_dict.get("ingredients", recipe_update.ingredients)
    recipe_update.servings = request_body_dict.get("servings", recipe_update.servings)
    recipe_update.instructions = request_body_dict.get("instructions", recipe_update.instructions)

    # Update the recipe in the recipes list
    recipe_index = next((index for index, r in enumerate(recipes) if r["id"] == recipe_update.id), None)
    if recipe_index is not None:
        recipes[recipe_index]["recipe"] = recipe_update
        return {"id": recipe_update.id, "recipe": recipe_update}
    else:
        raise HTTPException(status_code=404, detail="Recipe not found")
# Route to delete a recipe
@router.delete("/recipes", summary="Delete a recipe")
async def delete_recipe(
    request: Request,
    body_id: int = Body(..., embed=True, description="The ID of the recipe to be deleted"),
    token: str = Depends(ouath_scheme)
):
    """
    Delete a recipe.

    :param request: The FastAPI request object.
    :param body_id: The ID of the recipe to be deleted (from the request body).
    :param token: The OAuth token for authentication.

    :return: The deleted recipe.
    """
    global recipes
    recipe = next((r for r in recipes if r["id"] == body_id), None)
    if recipe:
        recipes = [r for r in recipes if r["id"] != body_id]
        return recipe
    else:
        raise HTTPException(status_code=404, detail="Recipe not found")
